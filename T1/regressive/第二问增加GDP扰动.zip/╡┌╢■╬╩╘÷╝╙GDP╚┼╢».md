第二问



单体-Ridge Model - GDP Increase 1%.svg
平均价格变化: 22961.6387438628
平均价格变化率: 11.152389626704858



单体-Ridge Model - GDP Increase 2%.svg
平均价格变化: 23212.55338660197
平均价格变化率: 11.274258012933196



单体-Ridge Model - GDP Increase 5%.svg
平均价格变化: 23968.307644105953
平均价格变化率: 11.641325278285859



单体-Ridge Model - GDP Increase 10%.svg
平均价格变化: 25238.005345097685
平均价格变化率: 12.258013121324758

------------------------------------------------

单体-CatBoostRegressor Model - GDP Increase 1%.svg
平均价格变化: 9793.644339819468
平均价格变化率: 5.109002212932175



单体-CatBoostRegressor Model - GDP Increase 2%.svg
平均价格变化: 9901.424367520638
平均价格变化率: 5.165227289209075



单体-CatBoostRegressor Model - GDP Increase 5%.svg
平均价格变化: 9699.296868347417
平均价格变化率: 5.059784432113299



单体-CatBoostRegressor Model - GDP Increase 10%.svg
平均价格变化: 10281.656438447826
平均价格变化率: 5.363581081157231