第二问



单体-Ridge Model - GDP Increase 1%.svg
平均价格变化: 22961.6387438628
平均价格变化率: 11.152389626704858



单体-Ridge Model - GDP Increase 2%.svg
平均价格变化: 23212.55338660197
平均价格变化率: 11.274258012933196



单体-Ridge Model - GDP Increase 5%.svg
平均价格变化: 23968.307644105953
平均价格变化率: 11.641325278285859



单体-Ridge Model - GDP Increase 10%.svg
平均价格变化: 25238.005345097685
平均价格变化率: 12.258013121324758

-

单体-CatBoostRegressor Model - GDP Increase 1%.svg
平均价格变化: 9793.644339819468
平均价格变化率: 5.109002212932175



单体-CatBoostRegressor Model - GDP Increase 2%.svg
平均价格变化: 9901.424367520638
平均价格变化率: 5.165227289209075



单体-CatBoostRegressor Model - GDP Increase 5%.svg
平均价格变化: 9699.296868347417
平均价格变化率: 5.059784432113299



单体-CatBoostRegressor Model - GDP Increase 10%.svg
平均价格变化: 10281.656438447826
平均价格变化率: 5.363581081157231


-------------------------------

双体-Ridge Model - GDP Increase 1%.svg
平均价格变化: 30227.811425498105
平均价格变化率: 6.875323893128995


双体-Ridge Model - GDP Increase 2%.svg
平均价格变化: 30549.27902847051
平均价格变化率: 6.948441786464755


双体-Ridge Model - GDP Increase 5%.svg
平均价格变化: 31516.4610122944
平均价格变化率: 7.1684275905570445


双体-Ridge Model - GDP Increase 10%.svg
平均价格变化: 33137.74610370101
平均价格变化率: 7.537189323572189


---

双体-CatBoostRegressor Model - GDP Increase 1%.svg
平均价格变化: 12350.798072363192
平均价格变化率: 2.6897615495518767


双体-CatBoostRegressor Model - GDP Increase 2%.svg
平均价格变化: 12991.883309471654
平均价格变化率: 2.8293773388034413


双体-CatBoostRegressor Model - GDP Increase 5%.svg
平均价格变化: 12926.781550586573
平均价格变化率: 2.8151994527404254

双体-CatBoostRegressor Model - GDP Increase 10%.svg
平均价格变化: 12926.781550586573
平均价格变化率: 2.8151994527404254